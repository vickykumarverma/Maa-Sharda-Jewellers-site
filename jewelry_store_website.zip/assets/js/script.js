async function loadProducts(){
  const res = await fetch('assets/products.json');
  return await res.json();
}
function cardTemplate(p){
  const tags = p.tags.map(t=>`<span class="tag">${t}</span>`).join('');
  return `
  <a class="card" href="product.html?id=${encodeURIComponent(p.id)}" aria-label="${p.name}">
    <img src="${p.image}" alt="${p.name}" loading="lazy">
    <div class="card-body">
      <div style="display:flex;justify-content:space-between;align-items:center;gap:.5rem">
        <h3 style="margin:0;font-size:1.05rem">${p.name}</h3>
        <span class="price">₹${p.price.toLocaleString('en-IN')}</span>
      </div>
      <div class="tags">${tags}</div>
    </div>
  </a>`
}
async function renderProducts(rootSelector, filter=""){
  const root = document.querySelector(rootSelector);
  root.innerHTML = '<div class="empty">Loading products…</div>';
  const products = await loadProducts();
  const q = filter.trim().toLowerCase();
  const filtered = products.filter(p => {
    if(!q) return true;
    const hay = (p.name + ' ' + p.category + ' ' + p.tags.join(' ')).toLowerCase();
    return hay.includes(q);
  });
  if(filtered.length === 0){
    root.innerHTML = '<div class="empty">No results for \"'+filter+'\"</div>';
  } else {
    root.innerHTML = filtered.map(cardTemplate).join('');
  }
}
function initSearch(inputSelector, onChange){
  const input = document.querySelector(inputSelector);
  if(!input) return;
  const doFilter = ()=> onChange(input.value);
  input.addEventListener('input', doFilter);
}
function getParam(name){
  const url = new URL(location.href);
  return url.searchParams.get(name);
}
async function renderProductDetail(){
  const id = getParam('id');
  const products = await loadProducts();
  const p = products.find(x=>x.id===id) || products[0];
  document.querySelector('#pd-img').src = p.image;
  document.querySelector('#pd-name').textContent = p.name;
  document.querySelector('#pd-price').textContent = '₹' + p.price.toLocaleString('en-IN');
  document.querySelector('#pd-cat').textContent = p.category;
  document.querySelector('#pd-tags').innerHTML = p.tags.map(t=>`<span class="tag">${t}</span>`).join('');
}