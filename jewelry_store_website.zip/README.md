# Nova Jewels — Static Website

A modern, multi-page jewellery store website built with HTML, CSS, and vanilla JS. Ready to deploy on GitHub Pages.

## Pages
- `index.html` — Home with search bar, hero, discounts/offers, and featured products.
- `collections.html` — All products with live search.
- `product.html` — Product details (driven by `?id=` query string).
- `about.html` — Brand story and values.
- `contact.html` — Contact form (demo alert).

## Run locally
Just open `index.html` in a browser. For search/product detail to load `products.json`, use a simple local server:

```bash
# Python 3
python -m http.server 8000
# then open http://localhost:8000
```

## Deploy to GitHub Pages
1. Create a new GitHub repo (e.g., `nova-jewels`).
2. Upload all files from this folder (or push via git).
3. In **Settings → Pages**, set **Source** to **Deploy from a branch**, select `main` and `/root` folder.
4. Visit your GitHub Pages URL.

---

© 2025 Nova Jewels