// Maa Sharda Jewellers - app.js
const DATA_URL = 'assets/products.json';

async function loadProducts(){
  const res = await fetch(DATA_URL);
  return await res.json();
}

function parseDiscount(d){
  if(!d) return 0;
  if(typeof d === 'number') return d/100;
  const m = d.match(/(\d+)%/);
  return m ? Number(m[1])/100 : 0;
}

function calcFinal(price, discountStr){
  const d = parseDiscount(discountStr);
  const final = Math.round(price * (1 - d));
  return {final, saved: price - final};
}

function createCard(p){
  const {final, saved} = calcFinal(p.price, p.discount);
  const div = document.createElement('div');
  div.className = 'card';
  div.innerHTML = `
    <img src="${p.image}" alt="${p.name}" loading="lazy">
    <div><strong>${p.name}</strong></div>
    <div class="meta">${p.category} · Rating: ${p.rating} · Last sold: ${p.lastSold}</div>
    <div class="price-row">
      <div class="orig">₹${p.price.toLocaleString()}</div>
      <div class="final">₹${final.toLocaleString()}</div>
      <div class="badge">${p.discount || ''}</div>
    </div>
    <div class="small">You save ₹${saved.toLocaleString()}</div>
    <div class="actions">
      <button class="btn primary" onclick="addToCart('${p.id}')">Add to Cart</button>
      <button class="btn ghost" onclick="buyNow('${p.id}')">Buy Now</button>
    </div>
  `;
  return div;
}

// Render functions
async function renderGrid(selector, filter=''){
  const container = document.querySelector(selector);
  if(!container) return;
  const prods = await loadProducts();
  const q = filter.trim().toLowerCase();
  const list = prods.filter(p => {
    if(!q) return true;
    return (p.name + ' ' + p.category + ' ' + (p.tags||'')).toLowerCase().includes(q);
  });
  container.innerHTML = '';
  list.forEach(p => container.appendChild(createCard(p)));
}

// Cart (localStorage)
function getCart(){ return JSON.parse(localStorage.getItem('ms_cart') || '[]'); }
function saveCart(c){ localStorage.setItem('ms_cart', JSON.stringify(c)); updateCartCount(); }

function findProductById(arr, id){ return arr.find(x=>x.id===id); }

async function addToCart(id){
  const prods = await loadProducts();
  const p = findProductById(prods, id);
  if(!p){ alert('Product not found'); return; }
  const cart = getCart();
  const entry = cart.find(e=>e.id===id);
  if(entry) entry.qty++;
  else cart.push({id, qty:1, name:p.name, price:p.price, discount:p.discount});
  saveCart(cart);
  alert('Added to cart');
}

function buyNow(id){
  // store single-item checkout
  localStorage.setItem('ms_buyNow', JSON.stringify({id, qty:1}));
  window.location.href = 'checkout.html';
}

function updateCartCount(){
  const cart = getCart();
  const n = cart.reduce((s,e)=>s+e.qty,0);
  document.querySelectorAll('#cartCount, #cartCount2').forEach(el=>{ if(el) el.textContent = n; });
  document.querySelectorAll('#cartCount').forEach(el=>{ if(el) el.textContent = n; });
  document.querySelectorAll('#cartCount2').forEach(el=>{ if(el) el.textContent = n; });
  const el = document.getElementById('cartCount');
  if(el) el.textContent = n;
  const el2 = document.getElementById('cartCount2');
  if(el2) el2.textContent = n;
}

async function renderCartArea(){
  const area = document.getElementById('cartArea');
  if(!area) return;
  const cart = getCart();
  if(cart.length===0){ area.innerHTML = '<div class="small">Your cart is empty</div>'; return; }
  const prods = await loadProducts();
  let html = '<table class="table"><thead><tr><th>Item</th><th>Price</th><th>Qty</th><th>Subtotal</th><th></th></tr></thead><tbody>';
  let total = 0;
  for(const item of cart){
    const p = findProductById(prods, item.id);
    const {final} = calcFinal(p.price, p.discount);
    const subtotal = final * item.qty;
    total += subtotal;
    html += `<tr><td>${p.name}</td><td>₹${final.toLocaleString()}</td><td><input type="number" min="1" value="${item.qty}" data-id="${item.id}" class="qtyInput" style="width:70px"></td><td>₹${subtotal.toLocaleString()}</td><td><button data-remove="${item.id}" class="btn ghost">Remove</button></td></tr>`;
  }
  html += `</tbody></table><div style="margin-top:10px"><strong>Total: ₹${total.toLocaleString()}</strong></div>`;
  area.innerHTML = html;

  // attach events
  area.querySelectorAll('.qtyInput').forEach(inp=>{
    inp.addEventListener('change', (e)=>{
      const id = e.target.getAttribute('data-id');
      const q = Math.max(1, parseInt(e.target.value||1));
      const cart = getCart();
      const ent = cart.find(x=>x.id===id);
      if(ent){ ent.qty = q; saveCart(cart); renderCartArea(); }
    });
  });
  area.querySelectorAll('[data-remove]').forEach(btn=>{
    btn.addEventListener('click', (e)=>{
      const id = e.target.getAttribute('data-remove');
      let cart = getCart();
      cart = cart.filter(x=>x.id!==id);
      saveCart(cart);
      renderCartArea();
    });
  });
}

// Checkout handling
async function initCheckout(){
  const form = document.getElementById('checkoutForm');
  const orderDiv = document.getElementById('orderResult');
  if(!form) return;
  // preload items (buyNow or full cart)
  const buyNow = JSON.parse(localStorage.getItem('ms_buyNow') || 'null');
  const cart = getCart();
  let items = [];
  const prods = await loadProducts();
  if(buyNow){
    const p = findProductById(prods, buyNow.id);
    items = [{name:p.name, qty:buyNow.qty, price: calcFinal(p.price,p.discount).final}];
  } else {
    for(const c of cart){
      const p = findProductById(prods, c.id);
      items.push({name:p.name, qty:c.qty, price:calcFinal(p.price,p.discount).final});
    }
  }
  const subtotal = items.reduce((s,it)=>s + it.price*it.qty, 0);
  const itemsHtml = items.map(it=>`<div>${it.name} x ${it.qty} — ₹${(it.price*it.qty).toLocaleString()}</div>`).join('');
  orderDiv.innerHTML = `<div class="small"><h4>Order Summary</h4>${itemsHtml}<div><strong>Payable: ₹${subtotal.toLocaleString()}</strong></div></div>`;

  form.addEventListener('submit', (e)=>{
    e.preventDefault();
    const formData = new FormData(form);
    const payload = Object.fromEntries(formData.entries());
    // demo "process payment"
    const orderId = 'MS' + Date.now();
    orderDiv.innerHTML += `<div style="margin-top:8px;color:green">Order placed successfully. Order ID: <strong>${orderId}</strong></div>`;
    // clear cart and buyNow
    localStorage.removeItem('ms_cart');
    localStorage.removeItem('ms_buyNow');
    updateCartCount();
    form.reset();
  });
}

// Load live metal prices (placeholder API key). If API fails, fallback to simulated price that fluctuates
let lastGold = null, lastSilver = null;
async function fetchMetalRates(){
  const apiKey = 'YOUR_API_KEY'; // <-- Replace with your key
  try{
    // Example Metals API endpoint (adjust depending on provider)
    const res = await fetch(`https://api.metalpriceapi.com/v1/latest?base=INR&symbols=XAU,XAG&apikey=${apiKey}`);
    const data = await res.json();
    // The returned format varies by provider. Try common structure
    // Some providers return rates like data.rates.XAU meaning 1 INR = XAU ounces — adjust safely
    if(data && data.rates && data.rates.XAU && data.rates.XAG){
      // Convert to INR per gram approximation:
      // Many APIs provide XAU as troy ounce rate relative to base. If rates are in INR per troy oz, convert: 1 troy oz = 31.1035 grams
      const goldVal = Number(data.rates.XAU);
      const silverVal = Number(data.rates.XAG);
      // If provider returns USD per ounce or similar, this code may need adjustment by API used.
      const goldPerGram = (1 / goldVal).toFixed(2);
      const silverPerGram = (1 / silverVal).toFixed(2);
      updateMetalUI(Number(goldPerGram), Number(silverPerGram));
      return;
    }
    throw new Error('Unexpected API response');
  }catch(err){
    // Fallback simulated price with slight random variation
    const baseGold = 6200; // sample INR per gram
    const baseSilver = 80; // sample INR per gram
    const jitter = (n)=> Math.max(1, Math.round(n * (1 + (Math.random()-0.5)/100)));
    const g = lastGold ? jitter(lastGold) : baseGold;
    const s = lastSilver ? jitter(lastSilver) : baseSilver;
    updateMetalUI(g, s);
  }
}

function updateMetalUI(gold, silver){
  // show up/down compared to last
  const gEl = document.getElementById('gold');
  const sEl = document.getElementById('silver');
  const gEl2 = document.getElementById('gold2');
  const sEl2 = document.getElementById('silver2');
  const gEl3 = document.getElementById('gold3');
  const sEl3 = document.getElementById('silver3');
  const gEl4 = document.getElementById('gold4');
  const sEl4 = document.getElementById('silver4');
  const format = (v, last)=> {
    const arrow = last===null ? '' : (v>last ? ' ↑' : (v<last ? ' ↓' : ''));
    return `₹${v.toLocaleString()}/g${arrow}`;
  };
  gEl && (gEl.textContent = format(gold, lastGold));
  sEl && (sEl.textContent = format(silver, lastSilver));
  gEl2 && (gEl2.textContent = format(gold, lastGold));
  sEl2 && (sEl2.textContent = format(silver, lastSilver));
  gEl3 && (gEl3.textContent = format(gold, lastGold));
  sEl3 && (sEl3.textContent = format(silver, lastSilver));
  gEl4 && (gEl4.textContent = format(gold, lastGold));
  sEl4 && (sEl4.textContent = format(silver, lastSilver));
  lastGold = gold; lastSilver = silver;
}

document.addEventListener('DOMContentLoaded', async ()=>{
  // render on pages
  if(document.getElementById('grid')) renderGrid('#grid');
  if(document.getElementById('gridAll')) renderGrid('#gridAll');
  updateCartCount();
  if(document.getElementById('cartArea')) renderCartArea();
  if(document.getElementById('checkoutForm')) initCheckout();

  // search inputs
  const s = document.getElementById('search');
  if(s){ s.addEventListener('input', ()=> renderGrid('#grid', s.value)); }
  const s2 = document.getElementById('search2');
  if(s2){ s2.addEventListener('input', ()=> renderGrid('#gridAll', s2.value)); }

  // checkout button on cart page
  const goCheckout = document.getElementById('goCheckout');
  if(goCheckout){ goCheckout.addEventListener('click', ()=> window.location.href='checkout.html'); }

  // fetch metal rates periodically (1 min)
  fetchMetalRates();
  setInterval(fetchMetalRates, 60000);
});