# Maa Sharda Jewellers — Static Site (v2)

Includes: discounts auto-calculation, add-to-cart, buy-now, cart page, checkout with delivery address + demo payment method, and live gold/silver ticker (placeholder API key).

## Run locally (single command)
Open terminal in project folder and run:
```
python -m http.server 8000
# then open http://localhost:8000
```

## Live metal rates
The app fetches from `https://api.metalpriceapi.com` by default. Replace `YOUR_API_KEY` inside `assets/app.js` with your API key.
If the API fails, the script will fallback to a simulated price that slightly fluctuates.

## Deploy
Upload contents to GitHub repo root and enable GitHub Pages (branch `main`, folder `/root`).

© 2025 Maa Sharda Jewellers
